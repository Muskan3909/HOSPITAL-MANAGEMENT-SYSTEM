

**LOGIN DETAILS** 

Doctor
user: Ruchi@gmail.com
pass: 12345

Admin
user: muskan@gmail.com
pass: programming

Patient
user: 0711345678
pass: 1234

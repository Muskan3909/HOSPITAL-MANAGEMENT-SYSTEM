

<nav role="navigation" class="navbar navbar-default real-nav" >
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand"><img src='data:image/webp;base64,UklGRqQKAABXRUJQVlA4TJcKAAAvr4AMEBEzbdso1b6EP+KBiOj/BBCohF05nRLzf5jCREHaBkz8C99xMP4KAQRAQdP/hOhwAgVB27Zx+NPe9kOIiAlAGqEP0Uq9tm1lezL3vfG0kEJSSxoy3KmHVrSFz567cR4exri/IUSyLavpYXGBABxA8uIq8rfDoG0jSQ67hbk87ykFbNuOt9n1famZZq7t3zZqpLaCeSt/22bSdrZt27ZX27YTBm4bKRovHDPfDxy2bRtI3H/sPztpix8gwkFtbUHzjIARMAKLgBF+I7AIEAEiQIQRwT+CRBgRRoQ5kCQ1bsA5JF9jjPDKT4AATnjz/A0ONGvSF/WLbJwDd+u9UrywX7Op5GEC7NBgfhCFjj1+WGQueMQGACS9o8disEMzL3cACZhsLCBodAGAvIybYIcGx5IQ0AEVojd6iJqbBcAxsEXYPLiOzKTGrASgRGOW5mStB5sELTYAAABK8SVqwC49yXMl0dTIBgwDmCDTOGk7cA9s0cuLl27+LQHi1JEhAWAnEEw05uMW2KHJvIZAhyTCPG0I3oaCGBk1loIdmq3LsgGCmWgGM8CskWQATTfYosnfmtzyhq75BgBoMr80onka9oMtQtskqM06qw4AgL+aZRl76QWbhJHJY00AAACrRjovWcZfHqcCrgAAgC64oetvy+HhAAAOE77szGc6JhDdUBrHvyDDBU4AQKlmjcBB69Jx489jcrDt4H0zirnYDaq42LJihLMmGcPgIrBBIHb8bQG4R5yWpE1WzqkDgjTEETwb++HKZwoMQGTmX+QKplAwQN644X9wjX9aEczBM9e8V+PlkYo6m4DkfoyFC594C8AglsYKaHSR0CF44ym4ChL/vnPwzhVpMTY+J39JpgvRcOFvDzmyQAAPYBBKsA0EQIiCAlzXSvN6Vh4nPQHhZB6AyC9IIgPAdNnAygSA7DDruNN9uHCY4XBYDFs8iwlMw4VwGCkQcABc3Mq/QTScPhEKr5GFFVDD2XS5eQBEWeLD3zUBtiECC9EEAJqwEBHYdtVZywz5DcB6ASr5AuC4UWQEtp4gmk8ldOUJ5QEIlZg/vB7Dg+yF/5rTB5uhBzfrjTWqg+4DDRrBzZivyT9w//6IBwB8cnz+4SgJJ4IdAMEunEqVhFwAwAPxx0Quyg80GAC3/2wX+QvpYjWugrsR1kpbfLh4uCjGGPh3JsOC5Yz60vHATZ0AILEaQIel4mZIW/g0dbgPwIwWGJoPM9dReI//Y4oFSE3IIgIjg/WCAUpIwFdfcj8/9OGP4IlXVVMQQw/q8SE8AVgrKSQldNyDI7Lux/jxxSHQARmLhXg4yNFes4A/JMgD/47RRYBXvmwBHimzgGOxWpV/czpqRIdq4pQFA2WgIYNkYb1J0TAQ4mOsDp5MAoAAwhFs//YogTYAABJCACZgBQIoRaGmNBCCiT04OePbASQYoxKLbVAADQsosRacoAMgh7/uOoH3VlesvYaxOMtgNi7Ein35jN5Mfcc+IHSagDRmbBuyQTppNoYyZGQAhBUID+fh+UfANZTjOAgEcAFepl7sbRDSaQzRKdONWBAyjaBpNLZAw6oHZwrDZMGxZqzSWfyBL78G6PhEGcxJ/jLSUpMUArNSnE2g6Gw/AEDZ8j/MUBJsMQcz1IsBgDUQUIVvQQB9sMW78r1JEy822FUAUBPWNz9kRJxoakHmE8kxTujWPjsV+JpE4VjAMPEXvrRh6QRgs+7i7CBdLDLjAGAUEVJl+gEA2IVsSGEAbzSB0BJiMR0C1ADg6xAMCazQhCYJ7OhCNwAAv6JILAAAKOmEi4HpB+fosTbbDP7HOQ6AYQDGWKMnQNeIAACQoQEAAILeCCjDBABBxAe4jxYAQGpa8MUp6AAwCEYPAABCBwAACBSdiOAU9mvyDDkxJz3jDLalIpgAlggPkaHA3Hyad+/ZYggiwlAKIxwsrsEiKcKvgMV3FQvYE6aAMCP0YwIn8TsAsdVBH5qxG9MApstJIxEpy8YuUH2VyRVMJSIxCs/mSAaYlVScB2dEU+Du22sZOi5UbKSfUpER/YF6BugAhq0gBOOEXHwcZhYSjFh+wHpUh0VtZAHCBTSHc6ER5goQfg4uQR9UAYB7aDI/AcGYy3/IhhNTWIAmKOOIVc0/GRqMNPyN2Sd7AJAB6MD1JlMk9N24UXHRkIQno2jEwQYhGFs0il3A0JARMV26jQnQAOEI5qAkvAtAIATDHZUBBUAp3hV7YBCMTAYhM/yxBcUWjcauIYNQHFB3Lr4mXj2kKqIw5gaNQLBzNVpExSAOBxslIxuEbAVmV5GLUQYpK50A5zORALB0hKvc4AlA6IUEp7AzAADy4GU2IFMwyEFgHovMeGhYozgIsA4KoUPYCMD51lft0lmQZhYjFjcPsEmlHWliogGDBRDkBdspAHAnWoiMpsscASAkiVPHA3II2AwCeIzTwR7W0GFGuInHyIOAQmzBZsilzNQAjCBAQo1M2wgACq0rJSC5bQAn0dNf96ykFxBlrgAVNdbt31RmSUJ7PrxUoW44xrEcd/6yXbEaAAAwjGKUYS4OAgBQCD8EoAEANCAAfigEAAf/8miIVhShEwAAsBWnwGnUYmLXd64tv4DhPVNQqaWXVSAAwLOnafPjjyRSSFXmVzSBMiP5puMs67ENXLniYg2Fh/OwldupsvMsgYlDG8ttIApO+fW3yFf3ZTIsl0aOcDA43EEwWWEjDoLr0DdbD/PcM3CHyJFhnlttrQNLycUsbyQhQyEN61kZMRTjBINgEi9Yc0cDUFsB2HYinIIskACAJXqabQF04cInJeJlAFqf1SsYK1gKBnkKtmjyf3FLokwHPgZAcs2/mCT7TQXYIgwjeXKmEQAA2B3mYgTs0pMYPeCXaUcdAIA50GQ8wijYomcXU+7+nQiIo1mCv0Dss1Xzs0HWEoQ2sEODTxMMRUx+YRpA+QbB5kNy/AV2aGADhAyQNGYZCn9MqJsU3WCHZpYaNYwazGEAwlNENGRGZTXYItwaWWCiQo10AoDEjk1wkv0XLOPr75vo42VAlO2WLALQXfhBOCkgC3aA+AAA7HzDpZZiW3PJoiJ9oLorCC074weYigb4aVLIx3gbyXlCF/hJCk4dd7ETAAAwhI0X/0ez7HkCAtKSSbfFBW8uWjZfQUNBVj/gZZRiEdR8ycz4GDbWI4fgun7b+shylAJV5muUgsQz/FaczVoU/y/vpopwj8YYwwsponPcJvY0Kjhz0iDBlFJdifyd4HzW0u70ejbIRdSZaGHNPiGDKHEFm8F/56kTMP5xc4gp+QnaORwAxeP2bmMoATGarPLMEJLJMgEtAqbRSJVzH4QAwQa5iQgygAZDCLnix3UMialBNFByAQdANTlGJF6VqeoPlFRj8mWSTqhJRVz54CZeBoKtnfqAWJrJAaFzE1ythrbDjE0A+B2A8Q4imx0U3VIZzb1pQzec33ATVIcJgVEYXybeo91sMrIEGAWq5TsATKb8ZJyxLgFcjrBegJ+iXJgFXjE5fZpu6hYWi01+xnioN+vRJFF0WF/sbgzjyMU6AADAOSxANbjK0K1784oCqLwjyqoinRiVVJhUdtXg1qGjuiOT5fFAKvcdyGM5AUH1MuMS7AA=' class='img-responsive img-logo' style="height: 50px; margin-bottom: 100px;" /></a>
        </div>
        <!-- Collection of nav links and other content for toggling -->
        <div id="navbarCollapse" class="collapse navbar-collapse">
			
            <ul class="nav navbar-nav navbar-right">
			
                <?php if(!User::loggedIn() && !Patient::isPatientIn() ) {?> 
               <li><a href='login.php'style='font-family: Georgia;font-size:20px;margin-top:9%'>Login</a></li>
               <?php } else {
                ?> 

               <!-- <li><a href='profile.php?token=<?php //echo $token; ?> '>Hello <?php// echo $userFirstName." ".$userSecondName; ?>,</a></li>--> 
			    <li><a href='logout.php'style='font-family: Georgia;font-size:20px;margin-top:9%'>Logout</a></li>
                <?php 
               } ?>
            </ul>
            
        </div>
    </div>
</nav>

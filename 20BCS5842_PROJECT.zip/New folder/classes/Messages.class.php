<?php 

class Messages{
	public static function success($message){
		echo "<div class='alert alert-success'style='color: #010429;'>$message <div class='close' data-dismiss='alert' >&times;</div></div>";
	}

	public static function info($message){
		echo "<div class='alert alert-info'style='color: #010429;'>$message <div class='close' data-dismiss='alert' >&times;</div></div>";
	}

	public static function error($message){
		echo "<div class='alert alert-danger'style='color: #010429;'>$message <div class='close' data-dismiss='alert' >&times;</div></div>";
	}
}
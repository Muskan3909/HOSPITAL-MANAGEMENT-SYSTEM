<?php 

class DashboardUi{
	public static function draw($title, $count, $url){
		echo "
			<div class='col-md-4'> 
				<div class='inner-panel'style='border: 2px solid #02012b; box-shadow: 4px 6px 2px ;
				'> 
					<h3 style='color: #010429; box-shadow: 4px 6px 2px ;'>$title</h3>
					<span class='d-count'>$count</span>
					<a href='$url'style='color: #010429;'>View &#8594;</a>
				</div> 
			</div> 
		";
	}
}